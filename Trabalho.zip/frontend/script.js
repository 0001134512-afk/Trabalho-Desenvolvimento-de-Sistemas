const API_URL = "http://localhost:3000";

// 🔹 CADASTRAR USUÁRIO
async function cadastrarUsuario(event) {
  event.preventDefault();

  const email = document.getElementById("email_usuario").value;
  const senha = document.getElementById("senha_usuario").value;

  try {
    const response = await fetch(`${API_URL}/usuario`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, senha }),
    });

    const result = await response.json();

    if (response.ok) {
      alert("Usuário cadastrado!");
      document.getElementById("form_cadastro_usuario").reset();
    } else {
      alert(result.message);
    }
  } catch (error) {
    console.error(error);
    alert("Erro ao conectar");
  }
}

// 🔹 LOGIN
async function login(event) {
  event.preventDefault();

  const email = document.getElementById("login_email").value;
  const senha = document.getElementById("login_senha").value;

  try {
    const response = await fetch(`${API_URL}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, senha }),
    });

    const result = await response.json();

    if (result.success) {
      alert("Login realizado com sucesso!");
    } else {
      alert("Email ou senha inválidos");
    }
  } catch (error) {
    console.error(error);
    alert("Erro no servidor");
  }
}

// 🔹 VINCULAR EVENTOS
document.addEventListener("DOMContentLoaded", () => {
  const formCadastro = document.getElementById("form_cadastro_usuario");
  if (formCadastro) {
    formCadastro.addEventListener("submit", cadastrarUsuario);
  }

  const formLogin = document.getElementById("loginForm");
  if (formLogin) {
    formLogin.addEventListener("submit", login);
  }
});

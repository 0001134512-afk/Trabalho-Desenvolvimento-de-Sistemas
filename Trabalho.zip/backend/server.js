const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

const db = mysql.createConnection({
  host: "127.0.0.1",
  port: 3306,
  user: "root",
  password: "User-12910",
  database: "sistema_login",
});

db.connect((err) => {
  if (err) {
    console.error("Erro ao conectar ao MySQL:", err);
    return;
  }
  console.log("Conectado ao MySQL com sucesso");
});

app.post("/login", (req, res) => {
  const { email, senha } = req.body;

  const sql = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";

  db.query(sql, [email, senha], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ mensagem: "Erro no servidor" });
    }

    if (result.length > 0) {
      return res.json({ mensagem: "Login OK" });
    } else {
      return res.json({ mensagem: "Email ou senha inválidos" });
    }
  });
});

app.listen(3000, () => {
  console.log("Servidor rodando na porta 3000");
});
